<<<<<<< .mine
Baahhhh
=======
Moo
>>>>>>> .r2
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace GoogleOne
{
	/// <summary>
	/// Summary description for Form.
	/// </summary>
	public class Form : System.Windows.Forms.Form
	{
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Button searchButton;

        private const string GOOGLE_KEY="RbrAPI5z+x86Lw61Id+Z72U3mXbvsphT";
        private System.Windows.Forms.TextBox resultBox;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
            this.SetStyle( ControlStyles.DoubleBuffer, true );
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.searchBox = new System.Windows.Forms.TextBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.resultBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // searchBox
            // 
            this.searchBox.Location = new System.Drawing.Point(8, 8);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(232, 20);
            this.searchBox.TabIndex = 0;
            this.searchBox.Text = "";
            this.searchBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.searchBox_KeyUp);
            // 
            // searchButton
            // 
            this.searchButton.Enabled = false;
            this.searchButton.Location = new System.Drawing.Point(248, 8);
            this.searchButton.Name = "searchButton";
            this.searchButton.TabIndex = 1;
            this.searchButton.Text = "Search";
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // resultBox
            // 
            this.resultBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.resultBox.Location = new System.Drawing.Point(0, 38);
            this.resultBox.Multiline = true;
            this.resultBox.Name = "resultBox";
            this.resultBox.Size = new System.Drawing.Size(408, 312);
            this.resultBox.TabIndex = 2;
            this.resultBox.Text = "";
            // 
            // Form
            // 
            this.AcceptButton = this.searchButton;
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(408, 350);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.resultBox,
                                                                          this.searchButton,
                                                                          this.searchBox});
            this.Name = "Form";
            this.Text = "Form";
            this.ResumeLayout(false);

        }
		#endregion

        private void searchButton_Click(object sender, System.EventArgs e)
        {
            GoogleSearchService srv = new GoogleSearchService();
            GoogleSearchResult res = srv.doGoogleSearch( GOOGLE_KEY, searchBox.Text, 0, 10, true, "", false, 
                "", "", "" );

            foreach ( ResultElement element in res.resultElements )
            {
                resultBox.Text += element.hostName + "\n" + element.snippet + "\n" +
                    element.title + "\n" + element.URL +"\n\n";
            }

        }

        [STAThread]
        public static void Main()
        {
            Application.Run( new Form() );
        }

        private void searchBox_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            searchButton.Enabled = searchBox.Text.Length > 0;
        }

	}
}
